﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Admin.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult StudentTable()
        {
            return View();
        }

        public ActionResult CreateStudent()
        {
            return View();
        }

        //[HttpPost]
        //public ActionResult CreateStudent(Students student)
        //{
        //    db.Students.Add(student);
        //    db.SaveChanges();
        //    return RedirectToAction("Index", "Students");
        //}
        //[HttpPost]
        //public bool Delete(int id)
        //{
        //    try
        //    {
        //        Students student = db.Students.Where(s => s.Id == id).First();
        //        db.Students.Remove(student);
        //        db.SaveChanges();
        //        return true;
        //    }
        //    catch (System.Exception)
        //    {
        //        return false;
        //    }

        //}
        //public ActionResult Update(int id)
        //{
        //    return View(db.Students.Where(s => s.Id == id).First());
        //}
        //[HttpPost]
        //public ActionResult UpdateStudent(Students tudent)
        //{
        //    Students d = db.Students.Where(s => s.Id == student.Id).First();
        //    d.FirstName = student.FirstName;
        //    d.LastName = student.LastName;
        //    d.Email = student.Email;
        //    d.Institution = student.Institution;
        //    d.Password = student.Password;
        //    db.SaveChanges();
        //    return RedirectToAction("Index", "Students");

        //}
    }
}