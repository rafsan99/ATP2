﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Admin.Controllers
{
    public class TeacherController : Controller
    {
        // GET: Teacher
        public ActionResult TeacherTable()
        {
            return View();
        }

        public ActionResult AddTeacher()
        {
            return View();
        }

        //[HttpPost]
        //public ActionResult CreateTeacher(Teachers teacher)
        //{
        //    db.Techers.Add(teacher);
        //    db.SaveChanges();
        //    return RedirectToAction("Index", "Teachers");
        //}
        //[HttpPost]
        //public bool Delete(int id)
        //{
        //    try
        //    {
        //        Teachers teacher = db.Teachers.Where(s => s.Id == id).First();
        //        db.Teachers.Remove(teacher);
        //        db.SaveChanges();
        //        return true;
        //    }
        //    catch (System.Exception)
        //    {
        //        return false;
        //    }

        //}
        //public ActionResult Update(int id)
        //{
        //    return View(db.Teachers.Where(s => s.Id == id).First());
        //}
        //[HttpPost]
        //public ActionResult UpdateTeacher(Teachers teacher)
        //{
        //    Teachers d = db.Teachers.Where(s => s.Id == teacher.Id).First();
        //    d.FirstName = teacher.FirstName;
        //    d.LastName = teacher.LastName;
        //    d.Email = teacher.Email;
        //    d.Institution = teacher.Institution;
        //    d.Password = teacher.Password;
        //    db.SaveChanges();
        //    return RedirectToAction("Index", "Teachers");

        //}

    }
}